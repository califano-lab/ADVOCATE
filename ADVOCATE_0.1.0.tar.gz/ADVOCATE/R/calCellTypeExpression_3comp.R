#' Inferring Epithelium, Stromal virtual Expression of give bulk PDA samples Expression
#'
#' \code{calCellTypeExpression} uses LCM compartment specific expression from experiments, output of predict_bulk_3comp to infer virtual epithelium/stromal compartment specific gene expression.
#'
#' @param lcmexp LCM sample expression
#' @param deg, result from hedgeBeta_deg
#' @param fc, output from hedgeBeta_deg
#' @param pval, output from hedgeBeta_deg
#' @param sampleInfo, output from hedgeBeta_deg
#' @param inputexpmat input bulk PDA sample normalized expression (VST and Z transformed)
#' @param fracAll result from predict_bulk_3comp
#' @param method method for inference, currently support 'lcm'
#' @return a matrix of n_gene * (nsample * 2)
#' @export
#' @author J.HE
calCellTypeExpression_3comp = function( lcmexp, deg, fc, pval,sampleInfo,# from the environment
                                        inputexpmat, fracAll, method = 'lcm') {
  #v1.2.0
  # fracAll: dataframe
  require(foreach); require(doMC); registerDoMC(2)
  g.prob =   intersect(rownames(inputexpmat), rownames(lcmexp) )
  g.global = setdiff(rownames(inputexpmat), g.prob)
  #####---------------------- find optimal Beta
  idxE = sampleInfo$compartment.id == 'E' | sampleInfo$compartment.id == 'Epithelium'
  idxS = sampleInfo$compartment.id == 'S' | sampleInfo$compartment.id == 'Stroma'
  idxE = intersect( colnames(lcmexp), sampleInfo$sample.id[idxE] )
  idxS = intersect( colnames(lcmexp), sampleInfo$sample.id[idxS] )
  lcmexp = lcmexp[g.prob,]
  param = estimateParam(lcmexp, idxE, idxS, k=2)
  inputexpmat.prob = inputexpmat[g.prob, ]
  allSamples = rownames(fracAll)
  expmatES.prob = foreach( i = 1:length(allSamples), .combine = cbind ) %dopar% {
    currSample = allSamples[i]

    ### this part is specific for 3comp
    ### TODO update calProbHedgeBeta with different options
    exp.currSample = inputexpmat.prob[,currSample]
    genes_probs = calProbHedgeBeta(exp.currSample,
                                   param,
                                   probType = 'raw')
    ### for 3 comp
    plow = 1e-6
    temp_  = param[, c('mu_Emain','mu_Esub' )]
    temp2_ = param[, c('mu_Smain','mu_Ssub' )]
    temp_low = unlist(apply(temp_,1,which.min) )
    temp_up  = unlist(apply(temp_,1,which.max) )
    idx_c1 = ( exp.currSample < f_rowMin(temp_) & f_rowMin(temp_) < f_rowMin(temp2_) &
                 vapply(1:length(temp_low), FUN=function(x) genes_probs[x,c(1,2)][temp_low[x]] < plow, T) ) |
      ( exp.currSample > f_rowMax(temp_) & f_rowMax(temp_) > f_rowMax(temp2_) &
          vapply(1:length(temp_up), FUN = function(x) genes_probs[x,c(1,2)][temp_up[x] ] < plow, T) )

    genes_probs[idx_c1, ] <- 0

    genes_probs[!idx_c1,] = genes_probs[!idx_c1,]/ rowSums(genes_probs[!idx_c1,])

    ### case 2, in btw 2 gaussian
    idx_c2 = (exp.currSample > param[, 'mu_Emain'] ) + (exp.currSample >  param[,'mu_Smain']) == 1
    temp_  = ( exp.currSample[idx_c2] - param[ idx_c2, 'mu_Smain'] ) /
      ( param[idx_c2 , 'mu_Emain'] - param[ idx_c2 , 'mu_Smain'])
    genes_probs[idx_c2,1] <- temp_
    genes_probs[idx_c2,3] <- 1 - temp_
    genes_probs[,c(2,4)]  = 0
    rm(temp_)
    tempES = genes_probs[, c(1,3)] * param[,c("mu_Emain","mu_Smain")]
    colnames(tempES) = paste(currSample, c('_E','_S'), sep = "")
    tempES
  }
  ## DEBUG ----
  ## before
  # expmatES.global = cbind(sweep(inputexpmat[g.global,allSamples],1,fracAll[,1], '*'),
  #                         sweep(inputexpmat[g.global,allSamples],1,fracAll[,2], '*'))
  ## after
  # expmatES.global = cbind(sweep(inputexpmat[g.global,allSamples],2,fracAll[,1], '*'),
  #                         sweep(inputexpmat[g.global,allSamples],2,fracAll[,2], '*'))
  expmatES.global = cbind( t(t(inputexpmat[g.global,allSamples]) * fracAll[,1]),
                           t(t(inputexpmat[g.global,allSamples]) * fracAll[,2]) )
  ### DEBUG END-------
  rownames(expmatES.global) = g.global
  cnames= c(paste(allSamples,rep('_E', length(allSamples)), sep=""),
            paste(allSamples,rep('_S', length(allSamples)), sep=""))
  colnames(expmatES.global) = cnames
  expmatES = rbind(expmatES.global[,cnames], expmatES.prob[,cnames])[rownames(inputexpmat),]
  return(expmatES)

}
