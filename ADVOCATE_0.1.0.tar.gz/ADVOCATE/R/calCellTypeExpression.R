#' Inferring Epithelium, Stromal virtual Expression of give bulk PDA samples Expression
#'
#' \code{calCellTypeExpression} uses LCM compartment specific expression from experiments, output of predict_bulk to infer virtual epithelium/stromal compartment specific gene expression.
#'
#' @param lcmexp LCM sample expression
#' @param deg, result from hedgeBeta_deg
#' @param fc, output from hedgeBeta_deg
#' @param pval, output from hedgeBeta_deg
#' @param sampleInfo, output from hedgeBeta_deg
#' @param inputexpmat input bulk PDA sample normalized expression (VST and Z transformed)
#' @param fracAll result from predict_bulk
#' @param method method for inference, currently support 'lcm'
#' @return a matrix of n_gene * (nsample * 2)
#' @export
#' @author J.HE
calCellTypeExpression = function( lcmexp, deg, fc, pval,sampleInfo, # from the environment
                                  inputexpmat, fracAll, method = 'lcm') {
  #v1.2.0
  ####----------------------
  ## calculate probability for contribution
  ####----------------------
  # fracAll: dataframe
  require(foreach); require(doMC); registerDoMC(2)
  g.prob =   intersect(rownames(inputexpmat), rownames(lcmexp) )
  g.global = setdiff(rownames(inputexpmat), g.prob)
  #####---------------------- find optimal Beta
  idxE = sampleInfo$compartment.id == 'E' | sampleInfo$compartment.id == 'Epithelium'
  idxS = sampleInfo$compartment.id == 'S' | sampleInfo$compartment.id == 'Stroma'
  idxE = intersect( colnames(lcmexp), sampleInfo$sample.id[idxE] )
  idxS = intersect( colnames(lcmexp), sampleInfo$sample.id[idxS] )
  lcmexp = lcmexp[g.prob,]
  param = estimateParam(lcmexp, idxE, idxS, k=2)
  inputexpmat.prob = inputexpmat[g.prob, ]
  allSamples = rownames(fracAll)
  if ( method == "lcm" ){
    expmatES.prob = foreach( i = 1:length(allSamples), .combine = cbind ) %dopar% {
      currSample = allSamples[i]
      genes_probs = calProbHedgeBeta(inputexpmat.prob[,currSample],
                                     param, probType = 'new')
      tempES = genes_probs[, c(1,3)] * param[,c("mu_Emain","mu_Smain")]
      colnames(tempES) = paste(currSample, c('_E','_S'), sep = "")
      tempES
    }
    ### DEBUGGED ----- Nov.02 2016
    ### before
#     expmatES.global = cbind(sweep(inputexpmat[g.global,allSamples],1,fracAll[,1], '*'),
#                             sweep(inputexpmat[g.global,allSamples],1,fracAll[,2], '*'))
    ## after
        expmatES.global = cbind(sweep(inputexpmat[g.global,allSamples],2,fracAll[,1], '*'),
                                sweep(inputexpmat[g.global,allSamples],2,fracAll[,2], '*'))
        ### (might be) faster version
#         expmatES.global = cbind( t(t(inputexpmat[g.global,allSamples]) * fracAll[,1]),
#                                  t(t(inputexpmat[g.global,allSamples]) * fracAll[,2]) )

        # first option
    #### DEBUGGED ----- Nov.02 2016

    cnames= c(paste(allSamples,rep('_E', length(allSamples)), sep=""),
              paste(allSamples,rep('_S', length(allSamples)), sep=""))
    colnames(expmatES.global) = cnames
    expmatES = rbind(expmatES.global[,cnames],
                     expmatES.prob[,cnames])[rownames(inputexpmat),]
    return(expmatES)

  }else if ( method == "prob") {
    betaFunc = 'beta'; fccut  = 1; pcut = 0.01; nsim = 1000

    expmatES = foreach( iCol = 1:NCOL(inputexpmat), .combine = cbind ) %dopar% {
      exp1colMat = subset(inputexpmat, select = iCol)
      frac = fracAll[colnames(exp1colMat),1:2]
      est_probs = calProbHedgeBeta(exp1colMat, param, probType = 'ml')
      est_probs = est_probs[,c(1,3)]
      simNormal = function(data) {
        n = data[1]; mu = data[2]; sigma = data[3]
        rnorm(n, mu, sigma)
      }

      calGeneExp = function(ig, p, frac ) {
        x0 = exp1colMat[ig,]
        fe = frac[1]; fs = frac[2]
        pe = p[1]; ps = p[2]
        prope = fe * max(pe , 1e-10)
        props = fs * max(ps , 1e-10)
        expe = x0 * prope / (props + prope)
        exps = x0 * props / (props + prope)
        t(c(expe,exps))
      }
      expES = foreach( ig = 1: length( allgene ), .combine = rbind ) %dopar%
      {
        g = allgene[ig]
        p = est_probs[ig, ]
        temp = calGeneExp(ig, p, unlist(frac))
        rownames(temp) = g
        temp
      }
      cat(colnames(exp1colMat), " finished", "\n")
      colnames(expES) = paste(colnames(exp1colMat),colnames(expES),sep = "_")
      expES
    }
    return( expmatES )
  }
}
