normalize_by_vst = function( rawcounts, designCond) {
  ## rawcounts: rawcount matrix
  ## genes have more than 5 counts in 80% of samples
  # idx_keep = rowSums(dataMat) >  2 * NCOL(dataMat)
  idx_keep = rowSums(rawcounts > 5) >  0.5 * NCOL(rawcounts)
  rawcounts = rawcounts[idx_keep,]

  require(DESeq2)
  dds <- DESeqDataSetFromMatrix(countData = as.matrix(rawcounts),
                                colData = designCond,
                                design = ~ condition)

  y = estimateSizeFactors(dds)
  y = estimateDispersions(y)

  ##----- VST normalization  with design
  dataout = varianceStabilizingTransformation(y, blind = F)
  dataout = assay(dataout)
  expmat = dataout

  rownames(expmat) = rownames(dataout); colnames(expmat) = colnames(dataout)
  return(expmat)
}
