gaussiannMixture = function( x , k = NULL ){
  require(mclust);
  if ( is.null(k) ){

    gm = try(densityMclust(x, modelNames = 'E' ))
    if (class(gm) == "try-error"){
      gm = densityMclust(x,G=2, modelNames = 'E' )
    }
  }else{
    gm = densityMclust(x, G = k, modelNames = 'E' )
  }

  gmp =  gm$parameters;
  idx_ = order(gmp$pro, decreasing = T)

  if( gm$G == 2 ){
    ans = c(coef = unlist( gmp$pro[idx_] ), mu = unlist(gmp$mean[idx_] ),
            sigma = rep(sqrt(gmp$variance$sigmasq),2) )
  }else if(gm$G == 1){
    ans = c(coef = c( gmp$pro[idx_], 0 ), mu = rep( gmp$mean[idx_], 2 ),
            sigma = rep(sqrt(gmp$variance$sigmasq),2) )
  }else{
    ans = gaussiannMixture(x , k = 2 )
  }

  names(ans) = paste(rep(c('coef','mu', 'sigma'), each = 2),
                     rep(c('Smain', 'Ssub'), 3), sep = "_")
  return (ans)
}
