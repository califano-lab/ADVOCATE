#' Predict Epithelium and Stromal fraction of give bulk PDA samples expression
#'
#' \code{predict_bulk} uses probabilistic model to calculate the fraction of epithelium/stromal compartment using gene expression.
#'
#' @param trainfile train file generated using hedgeBeta_deg function.
#' @param bulkexp input bulk PDA sample normalized expression (VST and Z transformed)
#' @param epsilon accurray of estimation, default 0.01
#' @param betaFunc weighting metric for learning rate, defaul p-value
#' @return a matrix of number_inputbulkexp * 7, first 2 columns are the epithelium and stromal fractions
#' @export
#' @author J.HE
predict_bulk = function(trainfile, bulkexp, epsilon = 0.01, betaFunc = 'pval') {
  require(foreach)
  require(doMC)
  registerDoMC(2)
  load(trainfile)
  lcmexp = expmat; rm(expmat)

  stopifnot( NCOL(lcmexp) == NROW(sampleInfo) )
  stopifnot( 'sample.id' %in% colnames(sampleInfo) )
  # stopifnot( 'patient.id' %in% colnames(sampleInfo) )
  stopifnot( 'compartment.id' %in% colnames(sampleInfo) )

  g.comm = intersect(deg, rownames(bulkexp))
  stopifnot( length(g.comm) > 10 )

  bulkexp = bulkexp[g.comm, ]
  lcmexp = lcmexp[g.comm, ]
  nbulk = NCOL(bulkexp)

  idxE = intersect(colnames(lcmexp), getMatchES(sampleInfo)[[1]] )
  idxS = intersect(colnames(lcmexp), getMatchES(sampleInfo)[[2]] )
  lcmexp = lcmexp[g.comm,c(idxE, idxS)]

  param = estimateParam(lcmexp, idxE, idxS, k = 2)

  ptime = proc.time()
  predTest = foreach(iCol = 1:nbulk, .combine = rbind,
                     .errorhandling="pass") %dopar%
                     {
                       tempFrac = predFracHedgeBeta(trainfile,
                                                    bulkexp[,iCol], param,
                                                    betaFunc = betaFunc,
                                                    epsilon = epsilon )
                       rownames(tempFrac) = colnames(bulkexp)[iCol]
                       tempFrac
                     }
  cat( colnames(bulkexp),  ' finished in ',
       round( (proc.time() - ptime)[3], 3) , '\n')

  return(predTest)
}
