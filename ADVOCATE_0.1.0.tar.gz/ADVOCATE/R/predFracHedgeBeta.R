predFracHedgeBeta = function(trainfile, # for beta weight
                             exp1colMat = NULL,
                             param	= NULL,
                             betaFunc	= 'pval',
                             epsilon	= 0.01)
{
  # v.1.2.0
  ## exp1colMat: n * 1 matrix
  ## param: n * 16 matrix
  ## betaFunc type: character, 'prob'
  require(plyr)
  fccut = 0.5;  pcut = 0.01
  beta_ = weightBeta( trainfile, exp1colMat, param,
                      func = betaFunc, pcut = pcut,
                      fccut = fccut, blow = .5, bup = 1 )
  deg = rownames(param)
  beta_ = rescale(beta_[ deg ], to = c(0.5,1))
  est_probs = calProbHedgeBeta(exp1colMat, param, probType = 'new')

  hBeta  = function( est_probs ) {
    plow = 1e-5;  conf = 0.95
    frac0 = seq(0, 1, epsilon)
    p0 = rep(1/length(frac0), length(frac0))
    frac = frac0; pnow = p0
    genes = intersect( rownames(est_probs), names(exp1colMat))
    names(frac) = frac0
    options(scipen=999)
    genes = sample(genes)
    for( g in genes) {
      p = est_probs[g,c('Emain', 'Smain')]
      if (sum(p) < 0.001) next
      p = p / sum(p)
      err = abs(frac0 - p[1,1])
      frac = log(pnow) + err * log(beta_[g])
      frac = exp(frac) / sum(exp(frac))
      pnow = frac
    }

    # helper = order(frac,decreasing = T)
    # frac = sum( exp(log(frac0[ helper ]) + log(frac[helper])) /sum(frac[helper]) )

    temp = as.data.frame( cbind(var = frac0, p = frac) ) ;
    temp = ddply( temp, 'var', function(df) sum(df[,-1]))
    frac_conf = calConfInterval( temp, conf)

    frac = mean(frac0[which.max(frac)])

    frac = matrix(c(frac, 1 - frac, 0, frac_conf, 1 - frac_conf), ncol = 7)
    colnames(frac) = c("E",'S',"O", 'E_conf1', 'E_conf2','S_conf1', 'S_conf2')
    frac
  }
  return( hBeta(est_probs) )

}
