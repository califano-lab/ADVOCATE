weightBeta = function (trainfile, exp1colMat = NULL, param = NULL, func = 'pval', pcut = 0.01, fccut = 1, blow = 0.5, bup = 1 ) {

  load(trainfile)
  wfc = 1 / ifelse( fc < fccut, 1, fc)  ### the original FC has been logged.
  wpv = ifelse(log(pval) > log(pcut), 0,log(pval))

  require(scales);
  set.seed(1)
  if( func == 'beta' ) {
    w = wfc + wpv  ## better compare to each single one
    names( w ) = names( wfc )
    require(MASS)
    fit = fitdistr(rescale( w, to= c(blow, 0.9999) ), 'beta', list(shape1=5, shape2=1))
    b = rescale( rbeta(length(w), fit$estimate[1], fit$estimate[2]),
                 to = c(blow, bup) )
    b = sort(b)
    names(b) = names(w)
  }else if ( func == 'pval') {
    ## used in v1.2.0
    b = rescale(wpv, to = c(blow, bup) )
  }else if ( tolower(func) == 'pvalprob' & !is.null(param) & !is.null(exp1colMat) ) {

    est_probs = calProbHedgeBeta(exp1colMat, param, probType = 'ml')

    simNormal = function(data) { n = data[1]; mu = data[2]; sigma = data[3]; rnorm(n, mu, sigma); }

    p.ml.se = 0.005; nsim = 1000; wprobAll = NULL
    cal_wprob = function(ig) {
      d.e = c(nsim, param[ig,'mu_Emain'], param[ig, 'sigma_Emain'])
      den.e = simNormal(d.e)
      d.s = c(nsim, param[ig,'mu_Smain'], param[ig, 'sigma_Smain'])
      den.s = simNormal(d.s)
      x0 = rep(exp1colMat[ig], length(nsim) )

      p.whole = ( den.e - x0 ) /( den.e - den.s)
      u.e = param[ig,'mu_Emain']; st.e = param[ig, 'sigma_Emain']
      u.s = param[ig,'mu_Smain']; st.s = param[ig, 'sigma_Smain']

      p.ml = ( u.e - x0 ) /( u.e - u.s) ; # p.ml = est_probs[ig,'Smain']
      conf = 2 * ifelse(p.ml > 0, p.ml * st.s, - p.ml * st.s )
      wprob.s = sum( p.whole >= (p.ml - conf) & p.whole <= (p.ml + conf) )/ nsim

      p.whole = ( x0 - den.s ) /( den.e - den.s); # p.ml = est_probs[ig,'Emain']
      p.ml = (  x0 - u.s ) /( u.e - u.s)
      conf = 2 * ifelse(p.ml > 0, p.ml * st.e, - p.ml * st.e )
      wprob.e = sum( p.whole >= (p.ml - conf) & p.whole <= (p.ml + conf))  / nsim
      return( c( wprob.e, wprob.s) )
    }
    for (ig in rownames(param) )
    {
      wprob = cal_wprob(ig)
      wprobAll[ig] = ifelse(wprob[1] == 0, 1e-5, wprob[1])
      wprobAll[ig] = ifelse(wprob[2] == 0, wprobAll[ig] * 1e-5, wprobAll[ig] * wprob[2])
    }
    names(wprobAll) = rownames(param)
    b = rescale( rescale(wpv[deg], to = c(sqrt(blow), bup)) * rescale(-wprobAll[deg], to = c(sqrt(blow),bup)), to = c(blow, bup))
  }
  return(b)

}
