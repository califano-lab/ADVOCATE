getMatchES = function( smpdf ) {
  ## smpdf is a dataframe with
  ## sample.id, compartment.id, pair.id, [patient.id, block.id, etc]
  smpdf = smpdf[order(smpdf$pair.id),]
  idx.pair.id =  names(which(table(smpdf$pair.id) == 2))
  idxE = smpdf$sample.id[(smpdf$compartment.id %in% 'E' |
                            smpdf$compartment.id  %in% 'Epithelium') &
                           (smpdf$pair.id %in% idx.pair.id)]
  idxS = smpdf$sample.id[(smpdf$compartment.id %in% 'S' |
                            smpdf$compartment.id  %in% 'Stroma') &
                           (smpdf$pair.id %in% idx.pair.id)]

  return ( list(E=idxE, S=idxS) )
}

f_rowMin = function( x) apply(x, 1, min)
f_rowMax = function( x) apply(x, 1, max)
calConfInterval = function(d, conf) {
  # v 1.2.1
  # d = as.data.frame( cbind(var = frac0, p = frac) ) ;
  # d = ddply( d, 'var', function(df) sum(df[,-1]))
  ### given the density d(2 cols)
  Fn = cumsum( d[,2])
  conf_low = d[which(  Fn >  ( 1 - conf)/2 )[1], 1 ]
  conf_up  = d[which(  Fn > 1 - (1-conf)/2 )[1], 1 ]
  return(c(conf_low, conf_up))
}
