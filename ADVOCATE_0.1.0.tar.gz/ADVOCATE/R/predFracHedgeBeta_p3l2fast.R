predFracHedgeBeta_p3l2fast = function(trainfile, exp1colMat = NULL,  param	 = NULL, betaFunc	 = 'pval', epsilon	 = 0.01)
{
  # v 1.2.1
  ## exp1colMat: n * 1 matrix
  ## param: n * 16 matrix
  ## betaFunc type: character, 'prob'

  fccut = 0.5;  pcut = 0.01;  plow = 1e-5; conf = 0.95

  beta_ = weightBeta(trainfile, exp1colMat, param,
                     func = betaFunc, pcut = pcut,
                     fccut = fccut, blow = .5, bup = 1 )
  deg = rownames(param)

  beta_ = rescale(beta_[ deg ], to = c(0.5,1))

  est_probs = calProbHedgeBeta(exp1colMat, param, probType = 'raw')
  ### for 3 comp
  temp_ = param[, c('mu_Emain', 'mu_Smain')]
  temp_ = param[, c('mu_Emain','mu_Esub' )]
  temp2_ = param[, c('mu_Smain','mu_Ssub' )]
  temp_low = unlist(apply(temp_,1,which.min) )
  temp_up = unlist(apply(temp_,1,which.max) )
  idx_c1 = ( exp1colMat < f_rowMin(temp_) &
               f_rowMin(temp_) < f_rowMin(temp2_) &
               vapply(1:length(temp_low), FUN=function(x) est_probs[x,c(1,2)][temp_low[x]]< plow, T)  ) |
    ( exp1colMat > f_rowMax(temp_) &
        f_rowMax(temp_) > f_rowMax(temp2_) &
        vapply(1:length(temp_up), FUN = function(x) est_probs[x,c(1,2)][temp_up[x] ] < plow, T)  )

  est_probs[idx_c1, ] <- 0

  est_probs[!idx_c1,] = est_probs[!idx_c1,]/ rowSums(est_probs[!idx_c1,])

  ### case 2, in btw 2 gaussian
  idx_c2 = (exp1colMat > param[, 'mu_Emain'] ) + ( exp1colMat >  param[,'mu_Smain']) == 1
  temp_ = ( exp1colMat[idx_c2] - param[ idx_c2, 'mu_Smain'] ) /
    ( param[idx_c2 , 'mu_Emain'] - param[ idx_c2 , 'mu_Smain'])
  est_probs[idx_c2,1] <- temp_
  est_probs[idx_c2,3] <-  1 - temp_
  est_probs[,c(2,4)] = 0
  rm(temp_)


  calFrac = function(est_probs, t_eps, frac_1, frac_2) {
    require(plyr)
    conf  = 0.95;
    plow  = 1e-5;
    genes = rownames(est_probs)
    Ngene = length(genes)

    ### adaptive peak search
    seq1  = seq(frac_1[1], frac_1[2], t_eps)
    seq2  = seq(frac_2[1], frac_2[2], t_eps)
    n_eps = length( seq1 ) *  length( seq2 )

    frac0     = rep(1,2) %o% rep(0, n_eps )
    frac0[1,] = rep(seq1, length(seq2))
    frac0[2,] = rep(seq2, each = length(seq1))

    frac0  = subset(frac0, select = which(colSums(frac0) <= 1) )
    frac00 = rbind(frac0, 1- colSums(frac0))
    rownames(frac00) = c('E','S','O')
    p0   = rep(1/NCOL(frac0), NCOL(frac0))
    pnow = p0

    for( ig in 1: Ngene ) {
      g = genes[ig]
      p = est_probs[g,c('Emain','Smain')]  ### TODO ?

      err  = colSums(abs(frac0 - unlist(p) %o% rep(1,ncol(frac0)) ))
      frac = log(pnow) + err * log(beta_[g])
      frac = exp(frac) / sum(exp(frac))
      pnow = frac
    }
    temp = as.data.frame( cbind(var = frac0[1,], p = frac) ) ;
    temp = ddply( temp, 'var', function(df) sum(df[,-1]))
    frac_1 = calConfInterval( temp, conf)

    temp = as.data.frame( cbind(var = frac0[2,], p = frac) ) ;
    temp = ddply( temp, 'var', function(df) sum(df[,-1]))
    frac_2 = calConfInterval( temp, conf)

    frac = t( rowMeans( subset(frac00, select = which.max(frac) ) ))
    return( list(frac= frac, frac1 = frac_1, frac2 = frac_2) )
  }
  frac_1 = c(0, 1);
  frac_2 = c(0, 1)
  temp_epsilon = 0.1 ^ ( 1: -log10(epsilon) )

  for (ieps in 1: length(temp_epsilon) ) {
    t_eps  = temp_epsilon[ ieps ]
    ifrac  = calFrac(est_probs, t_eps, frac_1, frac_2)
    frac_1 = ifrac[[2]]
    frac_2 = ifrac[[3]]
    if(frac_1[1] == frac_1[2] & ieps != length(temp_epsilon) )
    {
      frac_1[1] = max(0, frac_1 - t_eps * 0.5)
      frac_1[2] = min(1, frac_1 + t_eps * 0.5)
    }
    if(frac_2[1] == frac_2[2] & ieps != length(temp_epsilon))
    {
      frac_2[1] = max(0, frac_2 - t_eps * 0.5)
      frac_2[2] = min(1, frac_2 + t_eps * 0.5)
    }
    frac = ifrac[[1]]
  }
  frac= t(as.matrix(c(unlist(frac), E_conf= frac_1, S_conf=frac_2) ))
  colnames(frac) = c("E",'S',"O", colnames(frac)[4:7])

  return(frac)
}
