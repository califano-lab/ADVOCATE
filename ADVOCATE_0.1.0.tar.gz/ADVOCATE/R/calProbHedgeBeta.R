calProbHedgeBeta = function(exp1colMat, param, probType = 'raw'){
  # v1.2.0
  ### exp1colMat: n * 1 matrix
  ### param : n * 16 matrix
  ### probType: string

  require(foreach); require(doMC); registerDoMC(2)
  idxWeight = grep( "weight", colnames(param))
  idxCoef = grep( "coef", colnames(param))
  idxMu = grep( "mu", colnames(param))
  idxSigma = grep( "sigma", colnames(param))

  m = length(exp1colMat)
  exp1colMat = cbind(exp1colMat, exp1colMat, exp1colMat, exp1colMat )
  exp1colMat = array(exp1colMat, dim=c(m, 4) );
  est_probs  = foreach(i= 1:m, .combine = rbind,
                       .errorhandling="pass") %dopar%
                       {
                         pnorm(unlist(exp1colMat[i,]),
                               unlist(param[i,idxMu] ), unlist(param[i,idxSigma] ) ,
                               lower.tail = T )
                       }
  delta = exp1colMat - param[, idxMu] ## expression more than mu
  est_probs[ delta > 0 ] <- 1 - est_probs[delta > 0 ]
  est_probs[ est_probs < 1e-80 ] <- 1e-80
  est_probs = est_probs * param[, idxCoef ] * param[, idxWeight ]
  colnames( est_probs ) = gsub( "weight_", "", colnames(param[,idxWeight]) )

  if ( probType == 'raw' ){
    return(est_probs)
  }else if( probType == 'new2'){
    ## experimental, not used
    e1 = 2^(param[, 'mu_Emain']); e2 = 2^(param[, 'mu_Smain'])
    a = 2^ exp1colMat[,1]
    idx_c1 = abs(e1 - e2) < 2
    f1 = runif(length( which(idx_c1 == T) ), 0, 1 )
    f2 = 1 - f1
    est_probs[idx_c1,1] <- f1
    est_probs[idx_c1,3] <- f2

    # p1 = e1 / ( e1 + e2); p2 = e2 / ( e1 + e2)
    idx_c2 = ( (a > e1 ) + ( a > e2   ) == 1 )
    idx_c2 = idx_c2 & !idx_c1
    f1 = ( a[idx_c2] - e2[idx_c2] ) / ( e1[idx_c2] - e2[idx_c2] )
    f2 = 1 - f1
    # f2 = ( a - e1 * p1 ) / ( e2 * p2 -e1 * p1 )
    est_probs[idx_c2,1] <- f1
    est_probs[idx_c2,3] <- f2
    est_probs[idx_c2,3] <- f2
    return(est_probs/rowSums(est_probs))

  }else if( probType == 'new'){
    ## candidate for 3 component prediction
    # plow = 0.0005
    # a =(exp1colMat[,1])
    # e1 = param[, c('mu_Emain','mu_Esub' )]; e2 = param[, c('mu_Smain','mu_Ssub' )]
    # temp_low = unlist(apply(e1,1,which.min) );  temp_up = unlist(apply(e1,1,which.max) )
    # id1 = ( a < f_rowMin(e1) & f_rowMax(e1) < f_rowMin(e2) ) | ( a > f_rowMax(e1) & f_rowMin(e1) > f_rowMax(e2) )
    # id2 = ( a < f_rowMin(e2) & f_rowMax(e2) < f_rowMin(e1) ) | ( a > f_rowMax(e2) & f_rowMin(e2) > f_rowMin(e1))
    # est_probs[id1, 1] <- 1;  est_probs[id1, c(2,3,4)] <-0
    # est_probs[id2, c(1,2,4)] <- 0;  est_probs[id1, 3] <-1

    # ###
    # a = (exp1colMat[,1])
    # e1 = param[, 'mu_Emain'] ; e2 = param[,'mu_Smain']
    # idx_c2 = ( (a > e1)  +  (a > e2)  == 1   )
    # f1 = ( a[idx_c2] - e2[idx_c2] ) / (e1[idx_c2] - e2[ idx_c2 ])
    # est_probs[idx_c2,1] <- f1;  est_probs[idx_c2,3] <-  1 - f1

    # est_probs[,c(2,4)] <- 0
    # est_probs[ !(idx_c2 | (id1|id2)), ] = est_probs[ !(idx_c2 | (id1|id2)),] / rowSums( est_probs[ !(idx_c2 | (id1|id2)),])

    ## binary prediction
    ## case 1: outside, TODO: add 3rd componenet
    est_probs = est_probs/ rowSums(est_probs)
    plow = 1e-5
    temp.m = param[, c('mu_Emain', 'mu_Smain')]
    temp.e = param[, c('mu_Emain','mu_Esub' )]
    temp.s = param[, c('mu_Smain','mu_Ssub' )]
    temp_low = unlist(apply(temp.e,1,which.min) )
    temp_up = unlist(apply(temp.e,1,which.max) )
    idx_c1 = ( exp1colMat[,1] < f_rowMin(temp.e) & f_rowMin(temp.e) < f_rowMin(temp.s) &
                 vapply(1:length(temp_low), FUN = function(x) est_probs[x,c(1,2)][temp_low[x] ]< plow, T)  ) |
      ( exp1colMat[,1] > f_rowMax(temp.e) & f_rowMax(temp.e) > f_rowMax(temp.s) &
          vapply(1:length(temp_up), FUN = function(x) est_probs[x,c(1,2)][temp_up[x] ] < plow, T)  )
    est_probs[idx_c1, ] <- 0

    ### case 2: in between, TODO: add fuzzy boundary
    idx_c2 = (exp1colMat[,1] > param[, 'mu_Emain'] ) + ( exp1colMat[,1] >  param[,'mu_Smain']) == 1
    temp_ = ( exp1colMat[idx_c2, 1] - param[ idx_c2, 'mu_Smain'] ) /
      ( param[idx_c2 , 'mu_Emain'] - param[ idx_c2 , 'mu_Smain'])
    est_probs[idx_c2,1] <- temp_
    est_probs[idx_c2,3] <-  1 - temp_
    est_probs[,c(2,4)] = 0

    # renormalize
    est_probs[ !(idx_c2 | idx_c1), ] = est_probs[ !(idx_c2 | idx_c1),] / rowSums( est_probs[ !(idx_c2 | idx_c1),])

    return(est_probs)

  }else if ( probType == 'ml' ) {

    ### case 2, in btw 2 gaussian, recalibrate probabilities
    idx_c2 = (exp1colMat[,1] > param[, 'mu_Emain'] ) + ( exp1colMat[,1] >  param[,'mu_Smain']) == 1
    temp_ = ( exp1colMat[idx_c2, 1] - param[ idx_c2, 'mu_Smain'] ) /
      ( param[idx_c2 , 'mu_Emain'] - param[ idx_c2 , 'mu_Smain'])
    est_probs[idx_c2,1] <- temp_
    est_probs[idx_c2,3] <-  1 - temp_
    est_probs[,c(2,4)] = 0
    rm(temp_)
    return( est_probs )
  }
}
