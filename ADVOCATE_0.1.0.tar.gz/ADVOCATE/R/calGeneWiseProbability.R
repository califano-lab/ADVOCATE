#' Calculate each genes probability of coming from Epithelium and Stromal compartment
#'
#' \code{calGeneWiseProbability} uses LCM gene expression from epithelium and stromal to calculate the bulk sample genes probability of epithelium/stromal compartment
#'
#' @param trainfile train file generated using hedgeBeta_deg function.
#' @param bulkexp input bulk PDA sample normalized expression (VST and Z transformed)
#' @param n_comp number of compatments, default 2
#' @param epsilon accurray of estimation, default 0.01
#' @param betaFunc weighting metric for learning rate, defaul p-value
#' @return a matrix of number_gene * (number_sample*2)
#' @export
#' @author J.HE

calGeneWiseProbability = function(trainfile, bulkexp, n_comp = 2, epsilon = 0.01, betaFunc = 'pval') {
  require(foreach); require(doMC); registerDoMC(2)
  load(trainfile)
  lcmexp = expmat; rm(expmat)

  stopifnot( NCOL(lcmexp) == NROW(sampleInfo) )
  stopifnot( 'sample.id' %in% colnames(sampleInfo) )
  stopifnot( 'compartment.id' %in% colnames(sampleInfo) )

  g.comm = intersect(deg, rownames(bulkexp))
  stopifnot( length(g.comm) > 10 )

  bulkexp = bulkexp[g.comm, ]
  lcmexp = lcmexp[g.comm, ]
  nbulk = NCOL(bulkexp)

  idxE = intersect(colnames(lcmexp), getMatchES(sampleInfo)[[1]] )
  idxS = intersect(colnames(lcmexp), getMatchES(sampleInfo)[[2]] )
  lcmexp = lcmexp[g.comm,c(idxE, idxS)]

  param = estimateParam(lcmexp, idxE, idxS, k = 2)


  require(plyr)
  fccut = 0.5;  pcut = 0.01;  plow = 1e-5; conf = 0.95

  beta_ = weightBeta( trainfile, exp1colMat, param,
                      func = betaFunc, pcut = pcut,
                      fccut = fccut, blow = .5, bup = 1 )
  deg = rownames(param)
  beta_ = rescale(beta_[ deg ], to = c(0.5,1))

  ptime = proc.time()
  if(n_comp == 2){
    est_probs = foreach(iCol = 1:nbulk, .combine = cbind,
                       .errorhandling="pass") %dopar%
                       {
                         currProb = calProbHedgeBeta(subset(bulkexp,select=iCol), param, probType = 'new')[,c('Emain', 'Smain')]
                         colnames(currProb) = paste0(colnames(bulkexp)[iCol],"_",colnames(currProb))
                         return(currProb)
                       }
    cat( colnames(bulkexp),  ' finished in ',
         round( (proc.time() - ptime)[3], 3) , '\n')
  }else if (n_comp == 3){


    est_probs = foreach(iCol = 1:nbulk, .combine = cbind,
              .errorhandling="pass") %dopar%
      {

        exp1colMat = subset(bulkexp,select = iCol)
        currProb = calProbHedgeBeta(exp1colMat, param, probType = 'raw')

        ### for 3 comp
        temp_ = param[, c('mu_Emain', 'mu_Smain')]
        temp_ = param[, c('mu_Emain','mu_Esub' )]
        temp2_ = param[, c('mu_Smain','mu_Ssub' )]
        temp_low = unlist(apply(temp_,1,which.min) )
        temp_up = unlist(apply(temp_,1,which.max) )
        idx_c1 = (exp1colMat < f_rowMin(temp_) &
                  f_rowMin(temp_) < f_rowMin(temp2_) &
                  vapply(1:length(temp_low), FUN=function(x) currProb[x,c(1,2)][temp_low[x]]< plow, T) ) |
                (exp1colMat > f_rowMax(temp_) &
                  f_rowMax(temp_) > f_rowMax(temp2_) &
                  vapply(1:length(temp_up), FUN = function(x) currProb[x,c(1,2)][temp_up[x] ] < plow, T)  )
        currProb[idx_c1, ] <- 0

        currProb[!idx_c1,] = currProb[!idx_c1,]/ rowSums(currProb[!idx_c1,])

        ### case 2, in btw 2 gaussian
        idx_c2 = (exp1colMat > param[, 'mu_Emain'] ) + ( exp1colMat >  param[,'mu_Smain']) == 1
        temp_ = ( exp1colMat[idx_c2] - param[ idx_c2, 'mu_Smain'] ) /
                  ( param[idx_c2 , 'mu_Emain'] - param[ idx_c2 , 'mu_Smain'])
        currProb[idx_c2,1] <- temp_
        currProb[idx_c2,3] <-  1 - temp_
        currProb[,c(2,4)] = 0
        rm(temp_)
        currProb = currProb[,c('Emain', 'Smain')]
        colnames(currProb) = paste0(colnames(bulkexp)[iCol],"_",colnames(currProb))
        return(currProb)
    }
    cat( colnames(bulkexp),  ' finished in ',
         round( (proc.time() - ptime)[3], 3) , '\n')
  }

  return(est_probs)
}
