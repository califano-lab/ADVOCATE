estimateParam = function(expmat, idxE, idxS, k= NULL){
  ### expmat: expression matrix, numeric
  ### idxE: cell E id
  ### idxS : cell S id
  ### return:  nDeg * 16 dataframe, with (coef, weight, mu, sigma ) * 4
  set.seed(1)
  ndeg = NROW(expmat)
  pS = vapply(1:NROW(expmat), FUN = function(i) gaussiannMixture(expmat[i,idxS], k=k), c(1,1,1,1,1,1));
  pE = vapply(1:NROW(expmat), FUN = function(i) gaussiannMixture(expmat[i,idxE], k=k), c(1,1,1,1,1,1));
  pE = t(pE); pS = t(pS); rownames( pS ) = rownames( pE ) = rownames(expmat)
  colnames(pS) = paste(rep(c('coef','mu', 'sigma'), each = 2), rep(c('Smain', 'Ssub'), 3), sep = "_")
  colnames(pE) = paste(rep(c('coef','mu', 'sigma'), each = 2), rep(c('Emain', 'Esub'), 3), sep = "_")

  fitParam = cbind(pE, pS)

  train_mu = fitParam[ ,grep('mu_',colnames(fitParam))];
  train_sigma = fitParam[ ,grep('sigma_',colnames(fitParam))] ;
  train_coef = fitParam[ , grep('coef_',colnames(fitParam))]

  temp_ = as.data.frame(train_coef);
  train_sdw = (1/temp_) *( 1/(1-temp_)); ### assign weight to each gene
  train_sdw[train_sdw!=1] <- 1 ## no weight
  rownames(train_sdw) = rownames(train_coef)
  colnames(train_sdw) = gsub("coef_", "weight_",colnames(train_coef))
  rm(temp_)

  nE = length(idxE); nS = length(idxS);
  temp_ = as.data.frame(train_sigma )
  temp_ = ( temp_[, grep('Emain', colnames(temp_)) ]^ 2 * (nE - 1)/(nE + nS) +
              temp_[, grep('Smain', colnames(temp_)) ]^ 2 * (nS-1)/(nE + nS) ) ^ ( 1/2 )
  temp_ = cbind(temp_, temp_, temp_, temp_)
  colnames(temp_) = colnames(train_sigma)
  train_sigma = temp_
  rm(temp_)

  param=cbind(as.data.frame(train_sdw), as.data.frame(train_coef),
              as.data.frame(train_mu), as.data.frame(train_sigma) )
  return(param)
}
