#' Calculate DEG and its weighting metric for ADVOCATE training
#'
#' \code{hedgeBeta_deg} uses raw LCM samples from epi and stroma to calculate DEG and the weight metric for ADVOCATE model training.
#'
#' @param rawcounts raw counts matrix from LCM RNAseq
#' @param idxE group1 (Epithelium) sample name
#' @param idxS group2 (stromal) sample name
#' @param outfile rda file name to stroe all metrics needed for trianing
#' @return NULL
#' @export
#' @author J.HE
hedgeBeta_deg = function(rawcounts, idxE, idxS,outfile = 'input_advocate_train.rda')
{
  # input rawcounts: raw counts
  # input group1 sample name
  # input group2 sample name

  idx_keep = rowMeans(rawcounts) > 5
  rawcounts = rawcounts[idx_keep, c(idxE, idxS)]
  designCond = as.data.frame(cbind(c(idxE, idxS),
                                   c(rep('E', length(idxE)),
                                     rep('S', length(idxS)))  ))
  colnames(designCond) = c("pid",'condition')

  require(DESeq2)
  dds <- DESeqDataSetFromMatrix(countData = as.matrix(rawcounts),
                                colData = designCond,
                                design = ~ condition)
  y = estimateSizeFactors(dds)
  y = estimateDispersions(y)

  ##----- VST normalization  with design
  dataout = varianceStabilizingTransformation(y, blind = F)
  dataout = assay(dataout)
  colnames(dataout) = colnames(rawcounts)

  ##---- Test for DEG
  y = DESeq(y)
  res <- results(y)
  resOrdered <- res[order(res[,6]),]

  ### hard coded thresholds
  pvalue = 0.05;  fc = 1

  ### mean of orignal counts
  bmean = mean( rowMeans( rawcounts) )

  ## recordering
  resOrdered = na.omit( resOrdered )

  deg = rownames( resOrdered[ resOrdered[,1] > bmean &
                                as.numeric(resOrdered[,6]) < pvalue  &
                                abs(as.numeric(resOrdered[,2]))  > fc, ]  )

  fc = abs(resOrdered[,'log2FoldChange'])
  names(fc) = rownames(resOrdered)
  pval = resOrdered[, 'padj']
  names(pval) = rownames(resOrdered)

  deg = deg[order(abs(resOrdered[deg,'log2FoldChange']),decreasing = T)]
  expmat = scale( dataout )
  sampleInfo =  as.data.frame(cbind(sample.id = c(idxE, idxS),
                              compartment.id = c(rep('E', length(idxE)), rep('S', length(idxS))),
                              pair.id = rep(1:length(idxE),times=2)))

  save( deg, fc, pval, expmat, sampleInfo, file = outfile)
}
